#!/bin/bash

# Caminho dos arquivos
DB_EMAIL="/var/send/emails.txt"   # Lista de destinatários
ASSUNTO_FILE="/var/send/assuntos.txt"    # Lista de assuntos
HTML_TEMPLATE="/var/send/template.html"  # Template do e-mail
REMETENTE_FILE="/var/send/remetentes.txt" # Lista de remetentes
POSTMASTER="/var/send/postmaster.txt"    # E-mail do postmaster
PASTA_ANEXO="/var/send/anexo"            # Pasta de anexos
PDF_ORIGINAL="/var/send/PAYMENT_COPY.pdf"  # Caminho do PDF original
LINK1_FILE="/var/send/link1.txt"         # Lista de links 1
LINK2_FILE="/var/send/link2.txt"         # Lista de links 2

# Verificação de arquivos obrigatórios
for file in "$DB_EMAIL" "$ASSUNTO_FILE" "$HTML_TEMPLATE" "$REMETENTE_FILE" "$POSTMASTER"; do
    if [[ ! -f "$file" ]]; then
        echo "Erro: Arquivo obrigatório não encontrado: $file"
        exit 1
    fi
done

# Função para criar o conteúdo do e-mail
criar_email() {
    local email="$1"
    local nome_pdf="$2"  # Nome do PDF renomeado

    # Gerar código aleatório de 4 dígitos para o assunto e remetente
    local codigo_aleatorio
    codigo_aleatorio=$(shuf -i 1000-9999 -n 1)

    # Gerar código aleatório de 6 dígitos para outros usos
    local codigo2
    codigo2=$(shuf -i 100000-999999 -n 1)

    # Escolher links aleatórios (se os arquivos existirem)
    local link1=""
    local link2=""
    if [[ -n "$LINK1_FILE" ]]; then
        link1=$(shuf -n 1 "$LINK1_FILE")
    fi
    if [[ -n "$LINK2_FILE" ]]; then
        link2=$(shuf -n 1 "$LINK2_FILE")
    fi

    # Carregar e personalizar o template HTML
    local conteudo_html
    conteudo_html=$(<"$HTML_TEMPLATE")

    # Substituir placeholders no template (se existirem)
    conteudo_html=${conteudo_html//\{email\}/$email}
    conteudo_html=${conteudo_html//\{hora\}/$(date +"%H:%M")}
    conteudo_html=${conteudo_html//\{dia_semana\}/$(date +"%A")}
    conteudo_html=${conteudo_html//\{codigo\}/$codigo_aleatorio}
    conteudo_html=${conteudo_html//\{codigo2\}/$codigo2}
    conteudo_html=${conteudo_html//\{link1\}/$link1}
    conteudo_html=${conteudo_html//\{link2\}/$link2}

    # Escolher assunto aleatório
    local assunto
    assunto=$(shuf -n 1 "$ASSUNTO_FILE")

    # Substituir placeholders no assunto com o número aleatório
    assunto=${assunto//\{codigo\}/$codigo_aleatorio}
    assunto=${assunto//\{codigo2\}/$codigo2}
    assunto=${assunto//\{link1\}/$link1}
    assunto=${assunto//\{link2\}/$link2}

    # Escolher remetente aleatório do arquivo de remetentes
    local remetente
    remetente=$(shuf -n 1 "$REMETENTE_FILE")

    # Inserir o código aleatório no nome do remetente
    remetente="${remetente//\{codigo\}/$codigo_aleatorio}"

    # E-mail do postmaster
    local postmaster
    postmaster=$(<"$POSTMASTER")

    # Gerar o e-mail formatado
    {
        echo "From: $remetente <$postmaster>"
        echo "To: $email"
        echo "Subject: $assunto"
        echo "MIME-Version: 1.0"
        echo "Content-Type: multipart/alternative; boundary=\"boundary1234\""
        echo ""
        echo "--boundary1234"
        echo "Content-Type: text/html; charset=UTF-8"
        echo "Content-Transfer-Encoding: 7bit"
        echo ""
        echo "$conteudo_html"
        echo "--boundary1234--"
    }
}

# Função para validar se o e-mail possui um domínio com registro MX
validar_registro_mx() {
    local email="$1"
    local dominio=$(echo "$email" | awk -F '@' '{print $2}')

    # Verifica se o domínio tem registro MX
    if ! timeout 40s host -t mx "$dominio" &>/dev/null; then
        return 1  # Retorna erro se não encontrar registro MX
    fi
    return 0  # Retorna sucesso se o registro MX existir
}

# Função para verificar se o e-mail é válido (se é um formato correto e tem um domínio com MX)
validar_email() {
    local email="$1"
    # Verifica se o e-mail tem o formato válido e se o domínio tem registro MX
    if [[ ! "$email" =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
        return 1  # E-mail inválido
    fi
    
    # Verifica se o domínio do e-mail tem um registro MX com timeout de 40 segundos
    if ! validar_registro_mx "$email"; then
        return 1  # Domínio sem registro MX ou não respondeu dentro do tempo
    fi

    return 0  # E-mail válido
}

# Função para enviar o e-mail
enviar_email() {
    local email="$1"
    
    # Gerar e-mail HTML e enviar
    local email_temp
    email_temp=$(criar_email "$email" "")

    if [ -z "$email_temp" ]; then
        echo "Erro: O conteúdo do e-mail está vazio para o e-mail $email"
        return  # Ignora esse e-mail e vai para o próximo
    fi

    # Enviar via sendmail
    if echo "$email_temp" | sendmail -t -oi; then
        echo "E-mail enviado para: $email"
        # Remover o destinatário do arquivo DB_EMAIL após envio
        sed -i "/^$email$/d" "$DB_EMAIL"
    else
        echo "Erro ao enviar para: $email"
    fi
}

# Processar envio de e-mails
contador=0
primeiro_email=1

while IFS= read -r email; do
    # Remover espaços em branco extras
    email=$(echo "$email" | sed 's/^[ \t]*//;s/[ \t]*$//')

    if [[ -n "$email" ]]; then
        # Se for o primeiro e-mail, envia diretamente
        if [[ $primeiro_email -eq 1 ]]; then
            enviar_email "$email"
            primeiro_email=0  # Marcar que já enviou o primeiro e-mail
        else
            # Verificar se o e-mail é válido antes de enviar
            if ! validar_email "$email"; then
                echo "E-mail inválido ou domínio sem registro MX: $email. Ignorando..."
                continue  # Ignora esse e-mail e vai para o próximo
            fi
            # Enviar o e-mail
            enviar_email "$email"
        fi

        contador=$((contador + 1))

        # Aguardar 40 segundos entre os envios para verificar a validade do próximo e-mail
        if ((contador < $(wc -l < "$DB_EMAIL"))); then
            sleep 55  # Aguardar 40 segundos
        fi
    fi
done < "$DB_EMAIL"

echo "Envios concluídos! Total de e-mails enviados: $contador"
