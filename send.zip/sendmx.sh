#!/bin/bash

# Carregar variáveis do .env
source /var/send/.env

# Define o caminho para os arquivos
ASSUNTO_FILE="/var/send/assuntos.txt"
REMETENTE_FILE="/var/send/remetentes.txt"
POSTMASTER_FILE="/var/send/postmaster.txt"  # Arquivo com o endereço de e-mail do postmaster
LINK1_FILE="/var/send/link1.txt"           # Arquivo com links para substituir
LINK2_FILE="/var/send/link2.txt"           # Arquivo com links para substituir
LINK3_FILE="/var/send/link3.txt"           # Arquivo com links para substituir
LINK4_FILE="/var/send/link4.txt"           # Arquivo com links para substituir
HTML_TEMPLATE="/var/send/template.html"    # Caminho para o template HTML

# Função para obter o nome do usuário do e-mail
obter_nome_usuario() {
    local email="$1"
    echo "${email%%@*}"  # Extrai a parte antes do "@" do e-mail
}

# Função para substituir o marcador {nome_usuario} pelo nome do usuário
substituir_nome_usuario() {
    local conteudo="$1"
    local nome_usuario="$2"
    echo "${conteudo//\{nome_usuario\}/$nome_usuario}"  # Substitui {nome_usuario} pelo nome real
}

# Função para gerar um número aleatório de 4 dígitos (hash)
gerar_hash_aleatorio() {
    echo $((RANDOM % 10000))  # Gera um número aleatório de 4 dígitos
}

# Função para carregar o conteúdo HTML e substituir (####) por um hash aleatório
alterar_template_html() {
    local conteudo="$1"
    # Substituir todas as ocorrências de (####) por um hash aleatório de 4 dígitos
    echo "${conteudo//\(\#\#\#\#\)/$(gerar_hash_aleatorio)}"
}

# Função para carregar um assunto aleatório do arquivo de assuntos
carregar_assunto() {
    if [[ ! -f "$ASSUNTO_FILE" ]]; then
        echo "Arquivo de assuntos não encontrado: $ASSUNTO_FILE"
        exit 1
    fi
    shuf -n 1 "$ASSUNTO_FILE"
}

# Função para carregar o remetente aleatório do arquivo de remetentes
carregar_remetente() {
    if [[ ! -f "$REMETENTE_FILE" ]]; then
        echo "Arquivo de remetentes não encontrado: $REMETENTE_FILE"
        exit 1
    fi
    shuf -n 1 "$REMETENTE_FILE"
}

# Função para carregar o e-mail do postmaster a partir de um arquivo
carregar_postmaster() {
    if [[ ! -f "$POSTMASTER_FILE" ]]; then
        echo "Arquivo de postmaster não encontrado: $POSTMASTER_FILE"
        exit 1
    fi
    cat "$POSTMASTER_FILE"  # Lê o e-mail do postmaster
}

# Função para carregar um link aleatório de um arquivo de links
carregar_link() {
    local link_file="$1"
    if [[ ! -f "$link_file" ]]; then
        echo "Arquivo de links não encontrado: $link_file"
        exit 1
    fi
    shuf -n 1 "$link_file"  # Escolhe um link aleatório
}

# Função para carregar o conteúdo do template HTML
carregar_conteudo_html() {
    if [[ ! -f "$HTML_TEMPLATE" ]]; then
        echo "Arquivo HTML não encontrado: $HTML_TEMPLATE"
        exit 1
    fi
    cat "$HTML_TEMPLATE"
}

# Função para criar o e-mail com anexos em formato MIME
criar_email() {
    local destinatario="$1"
    local nome_usuario
    nome_usuario=$(obter_nome_usuario "$destinatario")  # Extrai o nome do usuário

    # Carregar o conteúdo do template HTML
    local conteudo_html
    conteudo_html=$(carregar_conteudo_html)

    # Substituir o nome do usuário
    conteudo_html=$(substituir_nome_usuario "$conteudo_html" "$nome_usuario")

    # Alterar o template HTML, substituindo (####) por um número aleatório
    conteudo_html=$(alterar_template_html "$conteudo_html")

    # Carregar links aleatórios
    local link1
    link1=$(carregar_link "$LINK1_FILE")
    local link2
    link2=$(carregar_link "$LINK2_FILE")
    local link3
    link3=$(carregar_link "$LINK3_FILE")
    local link4
    link4=$(carregar_link "$LINK4_FILE")

    # Substituir links no template HTML
    conteudo_html=$(echo "$conteudo_html" | sed "s|(link1)|$link1|g")
    conteudo_html=$(echo "$conteudo_html" | sed "s|(link2)|$link2|g")
    conteudo_html=$(echo "$conteudo_html" | sed "s|(link3)|$link3|g")
    conteudo_html=$(echo "$conteudo_html" | sed "s|(link4)|$link4|g")

    # Carregar o assunto e remetente
    local assunto
    assunto=$(carregar_assunto)  # Carregar o assunto corretamente agora
    local remetente
    remetente=$(carregar_remetente)  # Carregar o remetente corretamente agora
    local postmaster_email
    postmaster_email=$(carregar_postmaster)  # Carrega o e-mail do postmaster

    # Retornar o conteúdo do e-mail formatado
    {
        echo "From: $remetente <$postmaster_email>"  # Usando o e-mail do postmaster
        echo "To: $destinatario"
        echo "Subject: $assunto"  # Assegurar que o assunto está sendo passado corretamente
        echo "MIME-Version: 1.0"
        echo "Content-Type: text/html; charset=UTF-8"
        echo "Content-Transfer-Encoding: 7bit"
        echo ""
        echo "$conteudo_html"  # Corpo do e-mail com o conteúdo HTML
    }
}

# Função para enviar o e-mail usando sendmail
enviar_email() {
    local destinatario="$1"
    local email_temp
    email_temp=$(criar_email "$destinatario")

    # Enviar o conteúdo diretamente para o sendmail
    if echo "$email_temp" | sendmail -t; then
        echo "Enviado > ${destinatario}"
    else
        echo "Erro ao enviar e-mail para ${destinatario}"
    fi
}

# Enviar e-mails
enviar_emails() {
    if [[ ! -f "$DB_EMAIL" ]]; then
        echo "Arquivo de e-mails não encontrado: $DB_EMAIL"
        exit 1
    fi

    while IFS= read -r email; do
        email=$(echo "$email" | tr -d '[:space:]')
        if [[ -n "$email" ]]; then
            enviar_email "$email"
            sleep 30
        fi
    done < "$DB_EMAIL"
}

# Enviar os e-mails
enviar_emails

echo "Todos os e-mails foram enviados."
