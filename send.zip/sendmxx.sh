#!/bin/bash

# Caminho dos arquivos
DB_EMAIL="/var/send/emails.txt"   # Lista de destinatários
ASSUNTO_FILE="/var/send/assuntos.txt"    # Lista de assuntos
HTML_TEMPLATE="/var/send/template.html"  # Template do e-mail
REMETENTE_FILE="/var/send/remetentes.txt" # Lista de remetentes
POSTMASTER="/var/send/postmaster.txt"    # E-mail do postmaster
PASTA_ANEXO="/var/send/anexo"            # Pasta de anexos
PDF_ORIGINAL="/var/send/PAYMENT_COPY.pdf"  # Caminho do PDF original
LINK1_FILE="/var/send/link1.txt"         # Lista de links 1
LINK2_FILE="/var/send/link2.txt"         # Lista de links 2

# Verificação de arquivos obrigatórios
for file in "$DB_EMAIL" "$ASSUNTO_FILE" "$HTML_TEMPLATE" "$REMETENTE_FILE" "$POSTMASTER" "$PDF_ORIGINAL"; do
    if [[ ! -f "$file" ]]; then
        echo "Erro: Arquivo obrigatório não encontrado: $file"
        exit 1
    fi
done

# Função para criar o conteúdo do e-mail
criar_email() {
    local email="$1"
    local nome_pdf="$2"  # Nome do PDF renomeado

    # Carregar e personalizar o template HTML
    local conteudo_html
    conteudo_html=$(<"$HTML_TEMPLATE")

    # Gerar código aleatório de 4 dígitos
    local codigo_aleatorio
    codigo_aleatorio=$(shuf -i 1000-9999 -n 1)

    # Gerar código aleatório de 6 dígitos
    local codigo2
    codigo2=$(shuf -i 100000-999999 -n 1)

    # Escolher links aleatórios (se os arquivos existirem)
    local link1=""
    local link2=""
    if [[ -n "$LINK1_FILE" ]]; then
        link1=$(shuf -n 1 "$LINK1_FILE")
    fi
    if [[ -n "$LINK2_FILE" ]]; then
        link2=$(shuf -n 1 "$LINK2_FILE")
    fi

    # Substituir placeholders no template (se existirem)
    conteudo_html=${conteudo_html//\{email\}/$email}
    conteudo_html=${conteudo_html//\{hora\}/$(date +"%H:%M")}
    conteudo_html=${conteudo_html//\{dia_semana\}/$(date +"%A")}
    conteudo_html=${conteudo_html//\{codigo\}/$codigo_aleatorio}
    conteudo_html=${conteudo_html//\{codigo2\}/$codigo2}
    conteudo_html=${conteudo_html//\{link1\}/$link1}
    conteudo_html=${conteudo_html//\{link2\}/$link2}

    # Escolher assunto aleatório
    local assunto
    assunto=$(shuf -n 1 "$ASSUNTO_FILE")
    assunto=${assunto//\{email\}/$email}
    assunto=${assunto//\{hora\}/$(date +"%H:%M")}
    assunto=${assunto//\{dia_semana\}/$(date +"%A")}
    assunto=${assunto//\{codigo\}/$codigo_aleatorio}
    assunto=${assunto//\{codigo2\}/$codigo2}
    assunto=${assunto//\{link1\}/$link1}
    assunto=${assunto//\{link2\}/$link2}

    # Escolher remetente aleatório
    local remetente
    remetente=$(shuf -n 1 "$REMETENTE_FILE")

    # E-mail do postmaster
    local postmaster
    postmaster=$(<"$POSTMASTER")

    # Gerar o e-mail formatado
    {
        echo "From: $remetente <$postmaster>"
        echo "To: $email"
        echo "Subject: $assunto"
        echo "MIME-Version: 1.0"
        echo "Content-Type: multipart/mixed; boundary=\"boundary1234\""
        echo ""
        echo "--boundary1234"
        echo "Content-Type: text/html; charset=UTF-8"
        echo "Content-Transfer-Encoding: 7bit"
        echo ""
        echo "$conteudo_html"
        echo "--boundary1234"
        echo "Content-Type: application/pdf; name=\"$nome_pdf\""
        echo "Content-Disposition: attachment; filename=\"$nome_pdf\""
        echo "Content-Transfer-Encoding: base64"
        echo ""
        base64 "$PASTA_ANEXO/$nome_pdf"
        echo "--boundary1234--"
    }
}

# Função para renomear o PDF e salvar na pasta 'anexo'
renomear_pdf() {
    local nome_usuario="$1"  # Nome do usuário para modificar o PDF
    local nome_pdf=""

    # Gera um nome aleatório para o PDF com o nome do usuário
    nome_pdf="${nome_usuario}_$(openssl rand -hex 4).pdf"

    # Verifica se o arquivo PDF original existe
    if [[ ! -f "$PDF_ORIGINAL" ]]; then
        echo "Arquivo PDF não encontrado: $PDF_ORIGINAL"
        exit 1
    fi

    # Limpa a pasta 'anexo' antes de salvar o novo arquivo
    rm -rf anexo/*

    # Copia o arquivo PDF original para a pasta 'anexo' com o nome modificado
    cp "$PDF_ORIGINAL" "$PASTA_ANEXO/$nome_pdf"

    echo "$nome_pdf"  # Retorna o nome do PDF renomeado
}

# Função para enviar o e-mail com o PDF
enviar_email() {
    local email="$1"
    local nome_usuario="$2"

    # Renomeia o PDF e obtém o nome do arquivo modificado
    local nome_pdf=$(renomear_pdf "$nome_usuario")

    # Usa a função criar_email para gerar o corpo do e-mail com o anexo PDF
    email_temp=$(criar_email "$email" "$nome_pdf")

    # Enviar via sendmail
    if echo "$email_temp" | sendmail -t -oi; then
        echo "Enviado para: $email"
        
        # Remover a linha de destinatário do arquivo DB_EMAIL após envio
        sed -i "/^$email$/d" "$DB_EMAIL"

        # Limpar a pasta de anexos após o envio
        rm -f "$PASTA_ANEXO/*"
    else
        echo "Erro ao enviar para: $email"
    fi
}

# Processar envio de e-mails
contador=0
while IFS= read -r email; do
    # Remover espaços em branco extras
    email=$(echo "$email" | sed 's/^[ \t]*//;s/[ \t]*$//')

    if [[ -n "$email" ]]; then
        # Aqui você pode substituir 'nome_usuario' por um identificador adequado
        enviar_email "$email" "$email"
        contador=$((contador + 1))

        # Aguardar 40 segundos entre os envios
        if ((contador < $(wc -l < "$DB_EMAIL"))); then
            sleep 40  # Aguardar 40 segundos sem echo
        fi
    fi
done < "$DB_EMAIL"

echo "Envios concluídos! Total de e-mails enviados: $contador"

