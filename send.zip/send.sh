#!/bin/bash

# Carregar variáveis do .env
source /var/send/.env

# Define o caminho para o arquivo PID
pidFile="/var/send/pid.txt"

# Função para obter o nome do usuário do e-mail
obter_nome_usuario() {
    local email="$1"
    echo "${email%%@*}"
}

# Função para substituir o marcador {nome_usuario} pelo nome do usuário
substituir_nome_usuario() {
    local conteudo="$1"
    local nome_usuario="$2"
    echo "${conteudo//\{nome_usuario\}/$nome_usuario}"
}

# Função para substituir o marcador '######' por um valor aleatório
substituir_aleatorio() {
    local conteudo="$1"
    local valor_aleatorio=$(openssl rand -hex 8)  # Gera um valor aleatório
    echo "${conteudo//######/$valor_aleatorio}"
}

# Carregar conteúdo do arquivo HTML
carregar_conteudo_html() {
    if [[ ! -f "$HTML_TEMPLATE" ]]; then
        echo "Arquivo HTML não encontrado: $HTML_TEMPLATE"
        exit 1
    fi
    cat "$HTML_TEMPLATE"
}

# Função para carregar o assunto e o remetente do config.txt
carregar_configuracao() {
    if [[ ! -f "$CONFIG_FILE" ]]; then
        echo "Arquivo de configuração não encontrado: $CONFIG_FILE"
        exit 1
    fi

    while IFS='=' read -r key value; do
        case "$key" in
            "ASSUNTO") SUBJECT="$value" ;;
            "REMETENTE") SENDER_NAME="$value" ;;
        esac
    done < "$CONFIG_FILE"
}

# Função para verificar e obter anexos
obter_anexos() {
    if [[ -d "$ATTACHMENTS_DIR" && "$(ls -A "$ATTACHMENTS_DIR")" ]]; then
        local anexos=""
        for arquivo in "$ATTACHMENTS_DIR"/*; do
            if [[ -f "$arquivo" ]]; then
                anexos="$anexos $arquivo"
            fi
        done
        echo "$anexos"
    fi
}

# Função para criar o e-mail com anexos em formato MIME
criar_email() {
    local destinatario="$1"
    local nome_usuario
    nome_usuario=$(obter_nome_usuario "$destinatario")
    local conteudo_html
    conteudo_html=$(substituir_nome_usuario "$HTML_CONTENT" "$nome_usuario")

    # Substitui o marcador '######' por valores aleatórios
    conteudo_html=$(substituir_aleatorio "$conteudo_html")

    local anexos=$(obter_anexos)
    local boundary="====$(date +%s)===="

    local email_temp=$(mktemp)
    
    {
        echo "From: $SENDER_NAME <$SENDER_EMAIL>"
        echo "To: $destinatario"
        echo "Subject: $SUBJECT"
        echo "MIME-Version: 1.0"
        echo "Content-Type: multipart/mixed; boundary=\"$boundary\""
        echo ""
        echo "--$boundary"
        echo "Content-Type: text/html; charset=UTF-8"
        echo "Content-Transfer-Encoding: 7bit"
        echo ""
        echo "$conteudo_html"
        
        for arquivo in $anexos; do
            echo "--$boundary"
            echo "Content-Type: application/octet-stream; name=\"$(basename "$arquivo")\""
            echo "Content-Transfer-Encoding: base64"
            echo "Content-Disposition: attachment; filename=\"$(basename "$arquivo")\""
            echo ""
            base64 "$arquivo"
            echo ""
        done
        echo "--$boundary--"
    } > "$email_temp"

    echo "$email_temp"
}

# Função para enviar o e-mail usando sendmail
enviar_email() {
    local destinatario="$1"
    local email_temp
    email_temp=$(criar_email "$destinatario")

    if sendmail -t < "$email_temp"; then
        echo "Enviado > ${destinatario}"
    else
        echo "Erro ao enviar e-mail para ${destinatario}"
    fi

    rm "$email_temp"
}

# Função para validar o formato do e-mail
validar_email() {
    local email="$1"
    # Expressão regular para validar o formato do e-mail
    if [[ "$email" =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
        return 0  # E-mail válido
    else
        return 1  # E-mail inválido
    fi
}

# Enviar e-mails
enviar_emails() {
    if [[ ! -f "$DB_EMAIL" ]]; then
        echo "Arquivo de e-mails não encontrado: $DB_EMAIL"
        exit 1
    fi

    local emails_enviados=0

    while IFS= read -r email; do
        email=$(echo "$email" | tr -d '[:space:]')
        if [[ -n "$email" ]]; then
            # Verifica se o e-mail é válido
            if validar_email "$email"; then
                # Chama o mod.sh passando o e-mail de destino para modificar o HTML
                ./mod.sh "$email"
                
                # Aguarda 1 segundo após o mod.sh alterar o HTML
                sleep 2
                
                # Envia o e-mail
                enviar_email "$email"
                
                # Aguarda 1 segundo após o envio do e-mail
                sleep 5
                
                # Remove o e-mail da lista após o envio
                sed -i "/$email/d" "$DB_EMAIL"
                
                emails_enviados=$((emails_enviados + 1))
            else
                echo "E-mail inválido: $email. Ignorando..."
            fi
        fi
    done < "$DB_EMAIL"

    if (( emails_enviados == 0 )); then
        echo "Nenhum e-mail foi enviado."
    else
        echo "$emails_enviados e-mails foram enviados com sucesso."
    fi
}

# Remove o PID antigo, se existir
if [[ -f "$pidFile" ]]; then
    oldPid=$(cat "$pidFile")
    if ps -p "$oldPid" > /dev/null 2>&1; then
        echo "Outro processo já está em execução (PID: $oldPid)."
        exit 1
    else
        rm "$pidFile"
    fi
fi

# Grava o PID do processo atual no arquivo PID
echo $$ > "$pidFile"

# Carregar o conteúdo do HTML e configurações
HTML_CONTENT=$(carregar_conteudo_html)
carregar_configuracao

# Enviar os e-mails
enviar_emails

# Remove o arquivo PID quando o processo terminar
rm "$pidFile"

echo "Todos os e-mails foram enviados."
