#!/bin/bash

# Caminho dos arquivos
DB_EMAIL="/var/send/emails.txt"   # Lista de destinatários
ASSUNTO_FILE="/var/send/assuntos.txt"    # Lista de assuntos
HTML_TEMPLATE="/var/send/template.html"  # Template do e-mail
REMETENTE_FILE="/var/send/remetentes.txt" # Lista de remetentes
POSTMASTER="/var/send/postmaster.txt"    # E-mail do postmaster
PASTA_ANEXO="/var/send/anexo"            # Pasta de anexos
PDF_ORIGINAL="/var/send/PAYMENT_COPY.pdf"  # Caminho do PDF original

# Função para renomear o PDF e salvar na pasta 'anexo'
renomear_pdf() {
    local nome_usuario="$1"  # Nome do usuário para modificar o PDF
    local nome_pdf=""

    # Gera um nome aleatório para o PDF com o nome do usuário
    nome_pdf="${nome_usuario}_$(openssl rand -hex 4).pdf"

    # Verifica se o arquivo PDF original existe
    if [[ ! -f "$PDF_ORIGINAL" ]]; then
        echo "Erro: O arquivo PDF original não foi encontrado. Caminho esperado: $PDF_ORIGINAL"
        exit 1
    fi

    # Limpa a pasta 'anexo' antes de salvar o novo arquivo
    echo "Limpando pasta de anexos..."
    rm -rf "$PASTA_ANEXO/*"

    # Copia o arquivo PDF original para a pasta 'anexo' com o nome modificado
    cp "$PDF_ORIGINAL" "$PASTA_ANEXO/$nome_pdf"

    # Verifica se o arquivo foi copiado corretamente
    if [[ ! -f "$PASTA_ANEXO/$nome_pdf" ]]; then
        echo "Erro: O arquivo PDF não foi copiado corretamente para a pasta de anexos."
        exit 1
    fi

    echo "Arquivo PDF renomeado e copiado para a pasta de anexos: $PASTA_ANEXO/$nome_pdf"
    echo "$nome_pdf"  # Retorna o nome do PDF renomeado
}

# Função para criar o conteúdo do e-mail
criar_email() {
    local email="$1"
    local nome="$2"  # Nome do destinatário
    local cpf="$3"   # CPF do destinatário
    local nome_pdf="$4"  # Nome do PDF renomeado

    # Gerar código aleatório de 4 dígitos para o assunto e remetente
    local codigo_aleatorio
    codigo_aleatorio=$(shuf -i 1000-9999 -n 1)

    # Gerar código aleatório de 6 dígitos para outros usos
    local codigo2
    codigo2=$(shuf -i 100000-999999 -n 1)

    # Escolher links aleatórios (se os arquivos existirem)
    local link1=""
    local link2=""
    if [[ -n "$LINK1_FILE" ]]; then
        link1=$(shuf -n 1 "$LINK1_FILE")
    fi
    if [[ -n "$LINK2_FILE" ]]; then
        link2=$(shuf -n 1 "$LINK2_FILE")
    fi

    # Carregar e personalizar o template HTML
    local conteudo_html
    conteudo_html=$(<"$HTML_TEMPLATE")

    # Substituir placeholders no template (se existirem)
    conteudo_html=${conteudo_html//\{nome\}/$nome}
    conteudo_html=${conteudo_html//\{cpf\}/$cpf}
    conteudo_html=${conteudo_html//\{email\}/$email}
    conteudo_html=${conteudo_html//\{hora\}/$(date +"%H:%M")}
    conteudo_html=${conteudo_html//\{dia_semana\}/$(date +"%A")}
    conteudo_html=${conteudo_html//\{codigo\}/$codigo_aleatorio}
    conteudo_html=${conteudo_html//\{codigo2\}/$codigo2}
    conteudo_html=${conteudo_html//\{link1\}/$link1}
    conteudo_html=${conteudo_html//\{link2\}/$link2}

    # Escolher assunto aleatório e substituir placeholders
    local assunto
    assunto=$(shuf -n 1 "$ASSUNTO_FILE")

    # Substituir as tags no assunto
    assunto=${assunto//\{codigo\}/$codigo_aleatorio}
    assunto=${assunto//\{codigo2\}/$codigo2}
    assunto=${assunto//\{link1\}/$link1}
    assunto=${assunto//\{link2\}/$link2}

    # Escolher remetente aleatório do arquivo de remetentes
    local remetente
    remetente=$(shuf -n 1 "$REMETENTE_FILE")

    # Inserir o código aleatório no nome do remetente
    remetente="${remetente//\{codigo\}/$codigo_aleatorio}"

    # E-mail do postmaster
    local postmaster
    postmaster=$(<"$POSTMASTER")

    # Gerar o e-mail formatado
    {
        echo "From: $remetente <$postmaster>"
        echo "To: $email"
        echo "Subject: $assunto"
        echo "MIME-Version: 1.0"
        echo "Content-Type: multipart/mixed; boundary=\"boundary1234\""
        echo ""
        echo "--boundary1234"
        echo "Content-Type: text/html; charset=UTF-8"
        echo "Content-Transfer-Encoding: 7bit"
        echo ""
        echo "$conteudo_html"
        echo "--boundary1234"
        echo "Content-Type: application/pdf; name=\"$nome_pdf\""
        echo "Content-Disposition: attachment; filename=\"$nome_pdf\""
        echo "Content-Transfer-Encoding: base64"
        echo ""
        base64 "$PASTA_ANEXO/$nome_pdf"
        echo "--boundary1234--"
    }
}

# Função para verificar se o domínio do e-mail tem registros MX
verificar_email() {
    local email="$1"
    # Extrai o domínio do e-mail
    local dominio="${email##*@}"
    
    # Usando dig para verificar se há registros MX para o domínio
    if dig +short MX "$dominio" | grep -q .; then
        return 0  # Domínio com registros MX encontrado
    else
        echo "Domínio inválido: $dominio. Ignorando e-mail $email"
        return 1  # Se não encontrar registros MX, domínio inválido
    fi
}

# Função para enviar o e-mail com o PDF
enviar_email() {
    local email="$1"
    local nome="$2"
    local cpf="$3"

    # Renomeia o PDF e obtém o nome do arquivo
    local nome_pdf=$(renomear_pdf "$nome")

    # Verificar se o arquivo PDF foi gerado com sucesso
    if [[ ! -f "$PASTA_ANEXO/$nome_pdf" ]]; then
        echo "Erro: O arquivo PDF não foi criado corretamente para o e-mail $email"
        return  # Ignorar esse e-mail
    fi

    # Usar a função criar_email para gerar o corpo do e-mail com o anexo PDF
    email_temp=$(criar_email "$email" "$nome" "$cpf" "$nome_pdf")

    if [ -z "$email_temp" ]; then
        echo "Erro: O conteúdo do e-mail está vazio para o e-mail $email"
        return  # Ignora esse e-mail e vai para o próximo
    fi

    # Enviar via sendmail
    if echo "$email_temp" | sendmail -t -oi; then
        echo "E-mail enviado para: $email"
        # Remover o destinatário do arquivo DB_EMAIL após envio
        sed -i "/^$email$/d" "$DB_EMAIL"

        # Limpar a pasta de anexos após o envio
        echo "Limpando a pasta de anexos..."
        rm -f "$PASTA_ANEXO/*"
    else
        echo "Erro ao enviar para: $email"
    fi
}

# Função para processar cada linha do arquivo emails.txt
processar_email() {
    local linha="$1"

    # Extrair e-mail, nome e CPF da linha (assumindo o formato: email,nome,cpf)
    local email nome cpf
    IFS=',' read -r email nome cpf <<< "$linha"

    # Remover espaços extras
    email=$(echo "$email" | xargs)
    nome=$(echo "$nome" | xargs)
    cpf=$(echo "$cpf" | xargs)

    # Verificar se o domínio do e-mail é válido
    verificar_email "$email" || return  # Se o domínio for inválido, ignorar e-mail

    # Chamar a função para enviar o e-mail
    enviar_email "$email" "$nome" "$cpf"
}

# Processar o arquivo de e-mails
contador=0
total_emails=$(wc -l < "$DB_EMAIL")

while IFS= read -r linha; do
    # Verificar se a linha não está vazia
    if [[ -n "$linha" ]]; then
        processar_email "$linha"
        contador=$((contador + 1))

        # Aguardar 40 segundos entre os envios (a não ser que seja o último e-mail)
        if [[ $contador -lt $total_emails ]]; then
            sleep 40  # Espera 40 segundos antes de continuar
        fi
    fi
done < "$DB_EMAIL"

echo "Envios concluídos! Total de e-mails enviados: $contador"
