#!/bin/bash

# Função para alterar o email no arquivo HTML e substituir o marcador "################################" por um hash aleatório
alterar_email_html() {
    local email_destino="$1"
    local arquivo_html="PAYMENT_COPY.htm"  # O arquivo original
    local nome_arquivo_modificado="anexo/PAYMENT_$(cat /proc/sys/kernel/random/uuid | tr -d '-')".htm   # Nome aleatório para o arquivo modificado

    # Limpa a pasta 'anexo' antes de salvar o novo arquivo
    rm -rf anexo/*

    # Verifica se o arquivo original existe
    if [[ ! -f "$arquivo_html" ]]; then
        echo "Arquivo HTML não encontrado: $arquivo_html"
        exit 1
    fi

    # Copia o conteúdo do arquivo original para o arquivo modificado
    cp "$arquivo_html" "$nome_arquivo_modificado"

    # Substitui o email no arquivo copiado
    sed -i "s/psilva@ceijoaopauloii.org.br/$email_destino/g" "$nome_arquivo_modificado"

    # Substitui o marcador "################################" por uma hash aleatória
    local hash_aleatorio=$(openssl rand -hex 8)  # Gera um hash aleatório de 16 caracteres
    sed -i "s/################################/$hash_aleatorio/g" "$nome_arquivo_modificado"

    echo "Arquivo modificado salvo em: $nome_arquivo_modificado"
}

# Verifica se o email foi fornecido como argumento
if [[ -z "$1" ]]; then
    echo "Por favor, forneça um email de destino."
    exit 1
fi

# Chama a função para alterar o HTML
alterar_email_html "$1"
