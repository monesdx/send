#!/bin/bash

# Define o caminho para o arquivo PID
pidFile="/var/send/pid.txt"

# Verifica se o arquivo PID existe
if [[ ! -f "$pidFile" ]]; then
    echo "Arquivo PID não encontrado: $pidFile"
    exit 1
fi

# Lê o PID do arquivo
pid=$(cat "$pidFile")

# Verifica se o processo com o PID está em execução
if ps -p "$pid" > /dev/null 2>&1; then
    echo "Parando o processo com PID: $pid"
    # Tenta parar o processo
    kill "$pid"
    
    # Verifica se o processo foi parado com sucesso
    if [[ $? -eq 0 ]]; then
        echo "Processo com PID $pid foi parado com sucesso."
        
        # Remove o arquivo PID
        rm "$pidFile"
    else
        echo "Erro ao parar o processo com PID: $pid"
    fi
else
    echo "Nenhum processo com PID $pid encontrado."
fi
