#!/bin/bash

# Caminho dos arquivos
DB_EMAIL="/var/send/destinatarios.txt"   # Lista de destinatários
ASSUNTO_FILE="/var/send/assuntos.txt"    # Lista de assuntos
HTML_TEMPLATE="/var/send/template.html"  # Template do e-mail
REMETENTE_FILE="/var/send/remetentes.txt" # Lista de remetentes
POSTMASTER="/var/send/postmaster.txt"    # E-mail do postmaster
PASTA_ANEXO="/var/send/anexo"            # Pasta de anexos
LINK1_FILE="/var/send/link1.txt"         # Lista de links 1
LINK2_FILE="/var/send/link2.txt"         # Lista de links 2

# Verificação de arquivos obrigatórios
for file in "$DB_EMAIL" "$ASSUNTO_FILE" "$HTML_TEMPLATE" "$REMETENTE_FILE" "$POSTMASTER"; do
    if [[ ! -f "$file" ]]; then
        echo "Erro: Arquivo obrigatório não encontrado: $file"
        exit 1
    fi
done

# Verificar se a pasta de anexos existe e não está vazia
if [[ -d "$PASTA_ANEXO" && $(ls -A "$PASTA_ANEXO") ]]; then
    ANEXOS=("$PASTA_ANEXO"/*)
else
    echo "Aviso: Pasta de anexos vazia ou não encontrada: $PASTA_ANEXO"
    ANEXOS=()
fi

# Verificar se os arquivos de links existem
if [[ ! -f "$LINK1_FILE" ]]; then
    echo "Aviso: Arquivo de links 1 não encontrado: $LINK1_FILE"
    LINK1_FILE=""
fi
if [[ ! -f "$LINK2_FILE" ]]; then
    echo "Aviso: Arquivo de links 2 não encontrado: $LINK2_FILE"
    LINK2_FILE=""
fi

# Função para criar o conteúdo do e-mail
criar_email() {
    local email="$1"
    local nome="$2"
    local cpf="$3"

    # Carregar e personalizar o template HTML
    local conteudo_html
    conteudo_html=$(<"$HTML_TEMPLATE")

    # Gerar código aleatório de 4 dígitos
    local codigo_aleatorio
    codigo_aleatorio=$(shuf -i 1000-9999 -n 1)

    # Gerar código aleatório de 6 dígitos
    local codigo2
    codigo2=$(shuf -i 100000-999999 -n 1)

    # Escolher links aleatórios (se os arquivos existirem)
    local link1=""
    local link2=""
    if [[ -n "$LINK1_FILE" ]]; then
        link1=$(shuf -n 1 "$LINK1_FILE")
    fi
    if [[ -n "$LINK2_FILE" ]]; then
        link2=$(shuf -n 1 "$LINK2_FILE")
    fi

    # Substituir placeholders no template (se existirem)
    conteudo_html=${conteudo_html//\{nome\}/$nome}
    conteudo_html=${conteudo_html//\{cpf\}/$cpf}
    conteudo_html=${conteudo_html//\{email\}/$email}
    conteudo_html=${conteudo_html//\{hora\}/$(date +"%H:%M")}
    conteudo_html=${conteudo_html//\{dia_semana\}/$(date +"%A")}
    conteudo_html=${conteudo_html//\{codigo\}/$codigo_aleatorio}
    conteudo_html=${conteudo_html//\{codigo2\}/$codigo2}
    conteudo_html=${conteudo_html//\{link1\}/$link1}
    conteudo_html=${conteudo_html//\{link2\}/$link2}
    conteudo_html=${conteudo_html//\{nome_email\}/$(echo "$email" | cut -d'@' -f1)}

    # Escolher assunto aleatório e personalizar
    local assunto
    assunto=$(shuf -n 1 "$ASSUNTO_FILE")
    assunto=${assunto//\{nome\}/$nome}
    assunto=${assunto//\{cpf\}/$cpf}
    assunto=${assunto//\{email\}/$email}
    assunto=${assunto//\{hora\}/$(date +"%H:%M")}
    assunto=${assunto//\{dia_semana\}/$(date +"%A")}
    assunto=${assunto//\{codigo\}/$codigo_aleatorio}
    assunto=${assunto//\{codigo2\}/$codigo2}
    assunto=${assunto//\{link1\}/$link1}
    assunto=${assunto//\{link2\}/$link2}

    # Escolher remetente aleatório
    local remetente
    remetente=$(shuf -n 1 "$REMETENTE_FILE")

    # E-mail do postmaster
    local postmaster
    postmaster=$(<"$POSTMASTER")

    # Gerar o e-mail formatado
    {
        echo "From: $remetente <$postmaster>"
        echo "To: $email"
        echo "Subject: $assunto"
        echo "MIME-Version: 1.0"
        echo "Content-Type: multipart/mixed; boundary=\"boundary1234\""
        echo ""
        echo "--boundary1234"
        echo "Content-Type: text/html; charset=UTF-8"
        echo "Content-Transfer-Encoding: 7bit"
        echo ""
        echo "$conteudo_html"
    }
}

# Função para enviar o e-mail com anexos
enviar_email() {
    local email="$1"
    local nome="$2"
    local cpf="$3"
    local email_temp
    email_temp=$(criar_email "$email" "$nome" "$cpf")

    # Preparar anexos (se existirem)
    if [[ ${#ANEXOS[@]} -gt 0 ]]; then
        for anexo in "${ANEXOS[@]}"; do
            if [[ -f "$anexo" ]]; then
                # Gerar nome único para o anexo
                local nome_anexo
                nome_anexo="${nome}_${cpf}_$(shuf -i 1000-9999 -n 1).${anexo##*.}"

                # Codificar o anexo em base64
                local anexo_codificado
                anexo_codificado=$(base64 -w 0 "$anexo")

                # Adicionar o anexo ao e-mail
                email_temp+=$'\n'
                email_temp+="--boundary1234"$'\n'
                email_temp+="Content-Type: $(file --mime-type -b "$anexo"); name=\"$nome_anexo\""$'\n'
                email_temp+="Content-Disposition: attachment; filename=\"$nome_anexo\""$'\n'
                email_temp+="Content-Transfer-Encoding: base64"$'\n'
                email_temp+=$'\n'
                email_temp+="$anexo_codificado"
            fi
        done
        # Fechar o boundary
        email_temp+=$'\n'
        email_temp+="--boundary1234--"
    fi

    # Enviar via sendmail
    if echo "$email_temp" | sendmail -t -oi; then
        echo "Enviado para: $email"
    else
        echo "Erro ao enviar para: $email"
    fi
}

# Processar envio de e-mails
contador=0
while IFS= read -r linha; do
    # Extrair email, nome e CPF da linha
    IFS=',' read -r email nome cpf <<< "$linha"

    # Remover espaços em branco extras
    email=$(echo "$email" | tr -d '[:space:]')
    nome=$(echo "$nome" | tr -d '[:space:]')
    cpf=$(echo "$cpf" | tr -d '[:space:]')

    # Verificar se o nome ou CPF estão ausentes
    if [[ -z "$nome" || -z "$cpf" ]]; then
        echo "Aviso: Nome ou CPF não fornecido para o e-mail: $email"
    fi

    if [[ -n "$email" ]]; then
        enviar_email "$email" "$nome" "$cpf"
        contador=$((contador + 1))

        # Aguardar 40 segundos entre os envios
        if ((contador < $(wc -l < "$DB_EMAIL"))); then
            sleep 40  # Aguardar 40 segundos sem echo
        fi
    fi
done < "$DB_EMAIL"

echo "Envios concluídos! Total de e-mails enviados: $contador"
